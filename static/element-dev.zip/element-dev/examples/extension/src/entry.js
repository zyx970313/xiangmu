import init from './app';

if (!window.ElementThemeRollerInit) {
  window.ElementThemeRollerInit = true;
  init();
}

